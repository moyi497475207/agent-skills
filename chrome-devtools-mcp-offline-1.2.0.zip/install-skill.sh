#!/usr/bin/env bash
# 单独安装 skill 文档到 Claude Code 用户目录
# 用法: ./install-skill.sh [目标目录]   (默认 ~/.claude/skills/chrome-devtools-cli)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_SRC="$SCRIPT_DIR/skill"
TARGET="${1:-$HOME/.claude/skills/chrome-devtools-cli}"

if [ ! -d "$SKILL_SRC" ]; then
  echo "错误: 找不到 skill 源目录 $SKILL_SRC" >&2
  exit 1
fi

mkdir -p "$TARGET"
cp -r "$SKILL_SRC"/. "$TARGET"/
echo "已复制 skill 到: $TARGET"
ls -la "$TARGET"
