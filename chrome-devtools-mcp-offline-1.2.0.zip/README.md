# chrome-devtools-mcp 离线安装包

适用于无法访问公网/npm 的执行机，将 `chrome-devtools-mcp` CLI 与其 skill 文档一次性部署。

- **包版本**: `chrome-devtools-mcp@1.2.0`
- **打包时间**: 2026-06-16
- **包大小**: ~2.6 MB（tgz）+ ~13 KB（skill 文档）

---

## 1. 包结构

```
offline-chrome-devtools/
├── chrome-devtools-mcp-1.2.0.tgz   # npm 离线包（已包含全部 runtime 依赖）
├── skill/                          # chrome-devtools-cli skill 文档
│   ├── SKILL.md
│   └── references/installation.md
├── install.sh                      # Linux/macOS/Git Bash 一键安装
├── install.bat                     # Windows CMD 一键安装
├── install-skill.sh                # 单独安装 skill 文档（*inx）
├── install-skill.bat               # 单独安装 skill 文档（Win）
└── README.md                       # 本文件
```

> 该 npm 包使用 rollup 把全部 10 个 runtime 依赖（puppeteer-core、lighthouse、yargs、semver、@modelcontextprotocol/sdk 等）打包进了 `build/src/third_party/index.js`，**无需联网拉取任何 npm 依赖**。

---

## 2. 前置条件（执行机需自备）

| 依赖 | 版本要求 | 离线获取方式 |
|---|---|---|
| **Node.js** | `>= 20.19.0` 或 `^22.12.0` 或 `>=23` | https://nodejs.org/en/download/ 下载对应平台的 installer（Windows: `.msi`；Linux: `.tar.xz`；macOS: `.pkg`）|
| **npm** | 随 Node 自带（≥10）| 同上 |
| **Chrome 浏览器** | 任意较新稳定版 | 系统已装即可；若无则下载 ChromeStandaloneSetup（Win）/ google-chrome-stable（Linux `.deb`/`.rpm`） / Chrome.pkg（macOS）|

> 如果执行机无法安装 Chrome，可以用 `--executablePath` 指向其他位置的 Chromium/Edge 二进制；详见第 6 节。

---

## 3. 安装步骤

### 方式 A：一键脚本（推荐）

**Windows**（CMD 或双击）：
```cmd
install.bat
```

**Linux / macOS / Git Bash**：
```bash
chmod +x install.sh
./install.sh
```

脚本会依次：
1. 校验 Node.js / npm 版本
2. 用 `npm install -g <tgz> --offline` 安装 CLI
3. 验证 `chrome-devtools` 命令可用
4. 写入 `CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS=1` 环境变量，避免每次启动尝试联网检查更新

### 方式 B：手动执行（脚本出问题时）

```bash
# Linux/macOS/Git Bash
npm install -g ./chrome-devtools-mcp-1.2.0.tgz --offline --no-audit --no-fund

# Windows CMD
npm install -g .\chrome-devtools-mcp-1.2.0.tgz --offline --no-audit --no-fund

# 把更新检查关掉（写进 ~/.bashrc 或 系统环境变量）
export CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS=1   # *inx
setx CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS 1       # Windows
```

### 方式 C：完全跳过 npm（无 npm 时）

```bash
# 1. 找一个可写目录作为 PREFIX
PREFIX="$HOME/.local"
mkdir -p "$PREFIX/lib/node_modules"
mkdir -p "$PREFIX/bin"

# 2. 解压 tgz 到 lib/node_modules
tar -xzf chrome-devtools-mcp-1.2.0.tgz \
    -C "$PREFIX/lib/node_modules/" \
    --transform 's,^package,chrome-devtools-mcp,'

# 3. 创建可执行脚本
cat > "$PREFIX/bin/chrome-devtools" <<'EOF'
#!/usr/bin/env bash
exec node "$HOME/.local/lib/node_modules/chrome-devtools-mcp/build/src/bin/chrome-devtools.js" "$@"
EOF
chmod +x "$PREFIX/bin/chrome-devtools"

# 4. 同样为 chrome-devtools-mcp 建一个链接
cp "$PREFIX/bin/chrome-devtools" "$PREFIX/bin/chrome-devtools-mcp"

# 5. 把 $PREFIX/bin 加到 PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
```

---

## 4. 安装 skill 文档

skill 是 Claude Code 读取的 markdown 文档（让 Claude 知道如何调用 CLI）。把 `skill/` 目录复制到 Claude Code 的 skills 目录即可：

```bash
# Linux/macOS/Git Bash
./install-skill.sh
# 或自定义路径
./install-skill.sh /path/to/.claude/skills/chrome-devtools-cli
```

```cmd
:: Windows
install-skill.bat
:: 或自定义路径
install-skill.bat C:\path\to\.claude\skills\chrome-devtools-cli
```

默认目标路径：
- Linux/macOS：`~/.claude/skills/chrome-devtools-cli/`
- Windows：`%USERPROFILE%\.claude\skills\chrome-devtools-cli\`

---

## 5. 验证

```bash
# 1. 查看版本（无需联网）
chrome-devtools --help | head -5

# 2. 启动后台 daemon（会拉起 Chrome）
chrome-devtools start

# 3. 查看 daemon 状态
chrome-devtools status

# 4. 列出当前页面
chrome-devtools list_pages

# 5. 关闭 daemon
chrome-devtools stop
```

正常情况 `status` 应输出 `running`。

---

## 6. 常见问题

### Q1: `chrome-devtools` 命令找不到
npm global bin 不在 PATH 中。
```bash
# 查 global bin 路径
npm config get prefix
# Linux/macOS: 把 <prefix>/bin 加进 PATH
# Windows: 把 <prefix> 加进 PATH
```

### Q2: 启动报 "Could not connect to Chrome"
该包**不会自动下载 Chrome**，依赖系统已安装的 Chrome。两种解决方式：

**a. 安装系统 Chrome**（推荐）
- Windows: 离线安装 ChromeStandaloneSetup64.exe
- Linux: `dpkg -i google-chrome-stable_*.deb` 或 `rpm -i google-chrome-stable_*.rpm`
- macOS: 安装 Google Chrome.pkg

**b. 用 `--executablePath` 指定其他 Chromium 内核浏览器**
```bash
chrome-devtools start --executablePath "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
# 或
chrome-devtools start --channel stable   # 明确要求系统 Chrome
```

支持的启动参数见 `chrome-devtools start --help`。

### Q3: `npm install -g` 权限不足
**不要用 sudo**。改用以下任一方案：
- 用 nvm 管理 Node（推荐，全局目录在用户家目录下）
- `npm config set prefix ~/.npm-global`，再把 `~/.npm-global/bin` 加进 PATH

### Q4: 离线机器没有 Node.js
去 https://nodejs.org/en/download/ 下载对应平台的离线包，提前用 U 盘等拷贝到执行机：
- Windows: `node-vXX.X.X-x64.msi`
- Linux x64: `node-vXX.X.X-linux-x64.tar.xz`（解压后 `bin/` 加进 PATH）
- macOS: `node-vXX.X.X.pkg`

---

## 7. 卸载

```bash
npm uninstall -g chrome-devtools-mcp
# 删除 skill 文档
rm -rf ~/.claude/skills/chrome-devtools-cli
# 删除用户缓存
rm -rf ~/.cache/chrome-devtools-mcp
```

---

## 8. 反馈

- 包来源：https://github.com/ChromeDevTools/chrome-devtools-mcp
- 上游 skill：https://github.com/ChromeDevTools/chrome-devtools-mcp/tree/main/skills/chrome-devtools-cli
- License：Apache-2.0（Chrome DevTools MCP），见 tgz 内 `LICENSE`
