#!/usr/bin/env bash
# chrome-devtools-mcp 离线安装脚本 (Linux / macOS / Git Bash)
# 用法: ./install.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TGZ="$SCRIPT_DIR/chrome-devtools-mcp-1.2.0.tgz"
SKILL_SRC="$SCRIPT_DIR/skill"

echo "[1/4] 检查 Node.js..."
if ! command -v node >/dev/null 2>&1; then
  echo "错误: 未检测到 node。请先安装 Node.js >= 20.19.0 (离线 nodejs.org 下载 node-vXX.X.X-pkg 或 tar.gz)" >&2
  exit 1
fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "错误: Node 版本过低 ($(node -v))，需要 >= 20.19.0" >&2
  exit 1
fi
echo "    node $(node -v) OK"

echo "[2/4] 检查 npm..."
if ! command -v npm >/dev/null 2>&1; then
  echo "错误: 未检测到 npm" >&2
  exit 1
fi
echo "    npm $(npm -v) OK"

echo "[3/4] 离线安装 chrome-devtools-mcp..."
npm install -g "$TGZ" --offline --no-audit --no-fund

echo "[4/4] 验证 CLI..."
if command -v chrome-devtools >/dev/null 2>&1; then
  echo "    chrome-devtools $(chrome-devtools --version 2>/dev/null || echo '(version unknown)') OK"
else
  echo "警告: chrome-devtools 不在 PATH 中。检查 npm global bin:" >&2
  npm bin -g 2>/dev/null || npm config get prefix
fi

# 关闭更新检查 (避免每次启动尝试联网)
case ":$PATH:" in
  *":$HOME/.bashrc:"*) SHELL_RC="$HOME/.bashrc";;
  *) SHELL_RC="$HOME/.profile";;
esac
if ! grep -q CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS "$SHELL_RC" 2>/dev/null; then
  echo '' >> "$SHELL_RC"
  echo '# 关闭 chrome-devtools-mcp 联网更新检查 (离线环境)' >> "$SHELL_RC"
  echo 'export CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS=1' >> "$SHELL_RC"
  echo "已写入 $SHELL_RC (重开终端生效)"
fi

echo ""
echo "安装完成。"
echo ""
echo "下一步:"
echo "  1. 确保系统已安装 Chrome 浏览器 (或准备 --executablePath)"
echo "  2. 安装 skill 文档: 把 dist/skill 目录复制到 ~/.claude/skills/chrome-devtools-cli/"
echo "  3. 测试: chrome-devtools status"
