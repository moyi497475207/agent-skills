@echo off
REM 单独安装 skill 文档到 Claude Code 用户目录
REM 用法: install-skill.bat [目标目录]   (默认 %USERPROFILE%\.claude\skills\chrome-devtools-cli)

setlocal enabledelayedexpansion
set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "SKILL_SRC=%SCRIPT_DIR%\skill"
if "%~1"=="" (
  set "TARGET=%USERPROFILE%\.claude\skills\chrome-devtools-cli"
) else (
  set "TARGET=%~1"
)

if not exist "%SKILL_SRC%" (
  echo 错误: 找不到 skill 源目录 %SKILL_SRC%
  exit /b 1
)

if not exist "%TARGET%" mkdir "%TARGET%"
xcopy "%SKILL_SRC%\*" "%TARGET%\" /E /I /Y /Q
echo 已复制 skill 到: %TARGET%
dir "%TARGET%"
endlocal
