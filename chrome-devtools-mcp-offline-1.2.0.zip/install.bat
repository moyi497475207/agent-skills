@echo off
REM chrome-devtools-mcp 离线安装脚本 (Windows CMD)
REM 用法: 双击或 install.bat

setlocal enabledelayedexpansion
set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "TGZ=%SCRIPT_DIR%\chrome-devtools-mcp-1.2.0.tgz"
set "SKILL_SRC=%SCRIPT_DIR%\skill"

echo [1/4] 检查 Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo 错误: 未检测到 node。请先安装 Node.js ^>= 20.19.0 (离线 nodejs.org 下载 .msi)
  exit /b 1
)
for /f "delims=. tokens=1" %%v in ('node -p "process.versions.node"') do set "NODE_MAJOR=%%v"
if %NODE_MAJOR% LSS 20 (
  echo 错误: Node 版本过低，需要 ^>= 20.19.0
  exit /b 1
)
echo     node OK

echo [2/4] 检查 npm...
where npm >nul 2>nul
if errorlevel 1 (
  echo 错误: 未检测到 npm
  exit /b 1
)
echo     npm OK

echo [3/4] 离线安装 chrome-devtools-mcp...
call npm install -g "%TGZ%" --offline --no-audit --no-fund
if errorlevel 1 (
  echo 错误: npm 安装失败
  exit /b 1
)

echo [4/4] 验证 CLI...
where chrome-devtools >nul 2>nul
if errorlevel 1 (
  echo 警告: chrome-devtools 不在 PATH。npm global bin:
  call npm config get prefix
) else (
  echo     chrome-devtools OK
)

REM 设置环境变量关闭更新检查 (当前用户)
setx CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS 1 >nul
echo 已设置 CHROME_DEVTOOLS_MCP_NO_UPDATE_CHECKS=1 (重开终端生效)

echo.
echo 安装完成。
echo.
echo 下一步:
echo   1. 确保系统已安装 Chrome 浏览器 (或准备 --executablePath)
echo   2. 安装 skill 文档: 把 %SKILL_SRC% 目录复制到 %USERPROFILE%\.claude\skills\chrome-devtools-cli\
echo   3. 测试: chrome-devtools status
endlocal
